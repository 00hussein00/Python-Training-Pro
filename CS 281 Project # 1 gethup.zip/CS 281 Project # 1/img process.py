"""
Name : Hussein Maher
ID   : 2020901155
YU-IT-CS

"""
# To edit the images we use a PIL library
from PIL import Image


# assign the image to variable img
img = Image.open("img.png")

# to print image //(1'st question)
img.show()

# to get height and width //(2'nd question) 
print (f"The Width of image is {img.size[0]} , and Height of image is {img.size[1]}")

# return the RGB values for specific pixel//(3'rd question) 
get_specific_values = img.load() 
try:
  row = int(input('The row  : '))
  column = int(input('The column : '))
  print(f"The RGB values is : {get_specific_values[column,row]}")
except: 
  print("\nAn error occurred when getting the number of row and column")



#get values for all pixels of it//(4'th question) 
pix_val = list(img.getdata())
print(pix_val)

#print the three channels //(5'th question) 
red,green,blue = img.split()
red.show()
green.show()
blue.show()

#Merge the three channels into one image and print it //(6'th question) 
merge_img = Image.merge("RGB",(red,green,blue))
merge_img.show() 

#Convert the image into Black and white image //(7'th question)
BW_img = img.convert("1")
BW_img.show()

# Convert the image into grayscale //(8'th question) 
#Assign the image to variable grayscale_img after convert in into grayscale
grayscale_img = img.convert("L")
# show the grayscale image //(8'th question Cont.)
grayscale_img.show()