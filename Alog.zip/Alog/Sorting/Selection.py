# -*- coding: utf-8 -*-

A = [9,75,5,3,3,1,5,98,46,89]

for i in range(len(A) -1):  #Worst case O(n^2)  #best case O(n^2)
    key = i             
    for j in range((i+1),(len(A)-1)):  #find min element
        if A[j] < A[key] :
            key = j
            
    if i != key :
        ii = A[i]
        kk = A[key]
        A[i] = kk
        A[key] = ii
        
    
print(A)        
    











