# -*- coding: utf-8 -*-

A = [9,75,5,3,3,1,5,98,46,89]

for i in range(len(A)): #Worst case O(n^2)
    key = A[i]          #best case O(n)
    j = i 
    while key > A[j -1] and j > 0:
        A[j] = A[j-1]
        j -= 1
    A[j] = key
    
print(A)        
    











