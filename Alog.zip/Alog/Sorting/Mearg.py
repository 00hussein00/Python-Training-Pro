# -*- coding: utf-8 -*-


A = [9,75,9,75,5,35,3]
new = []
def marge(A,p,m,r):
    C1 = 0 # index 1'st list
    C2 = m+1 # index 2'nd list  
    for i in range(len(A)):
        if A[C1] <= A[C2] :
            new.append(A[C1])
            C1 +=1
        else :
            new.append(A[C2])
            C2 +=1           


def MS(A,p,r):
    i1 = A.index(p)
    i2 = A.index(r)
    if i1 < i2 :
        mid = (i1 + i2) // 2
        MS(A,p,mid)
        MS(A,mid+1,r)
        marge(A,p,mid,r)
    else :
        print('sd')
      
    

MS(A,A[0],A[-1])
print(new)









