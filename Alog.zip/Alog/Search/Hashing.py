# -*- coding: utf-8 -*-



import ctypes
import selectors 

class Hashing ():
    
    def __init__(self,c = 10) : 
        self.A = (c*ctypes.py_object)()
        self.cap = c  # max size in array
        self.n = 0 # number of item
      
        
    def get_cap(self):
        return(self.cap)
    
    def set_cap(self,new):
        self.cap = new            

    def get_size(self):
        return self.n

    def is_empty(self):
        if self.n  == 0 :
            return True
        else :
            return False

    def is_full(self):
        if self.n == self.cap :
            return True
        return False

    def __len__ (self):
        return self.n

    def ind(self):
        return (len(self.A) //2)
    
    def append (self,X):
        if self.is_full():
            self._resize(2*self.cap)
        self.A[self.n] = X
        self.n+=1
        
    def _resize(self,b):
        B = (b*ctypes.py_object)()
        for i in range (self.n):
            B[i]=self.A[i]
        self.A=B
        self.cap = b

    def __str__(self) :
        list1 = []
        for i in range(len(self)):
            list1.append(str(f"{self.A[i]} : {i}"))           
        return str(list1)

    def insert(self,value,index):
        if self.is_full():
            self._resize(2*self.cap)
            self.append(value)
        else:
            if 0<= index<self.n:
                for I in range(self.n-1,index-1,-1) :#shift right
                    self.A[I+1]=self.A[I]
                self.A[index] = value
                self.n+=1

            else:
                raise Exception("Index out of range")

LL = Hashing()
LL.append(5)
print(LL)











