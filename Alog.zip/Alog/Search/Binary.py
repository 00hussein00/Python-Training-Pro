# -*- coding: utf-8 -*-


A = [0,1,2,3,4,5,6,7,8,9]
def binary_search(X,lo,hi,A):
    if lo > hi :
        raise Exception('Error')
    mid = (A.index(lo) + A.index(hi))//2
    if A[mid] == X :
        print(f'foun item in index {mid}')
        return 
    elif A[mid] < X:
        binary_search(X,mid +1 ,hi,A)
        
    elif A[mid] > X:
        binary_search(X,lo,mid - 1,A)
        
    else :
        raise Exception('not fond')
        

        
binary_search(9,A[0],A[-1],A)       







