# -*- coding: utf-8 -*-
A = [0,1,2,3,4,5,6,7,8,9]

def linear_search(x):        
    for i in range(len(A)): 
        if x == A[i]:
            print( f"Find in index : {i}")
            return
    print('not fond ')
    
linear_search(6) 
#; in worst case O(n)
# in best case O(1)