




class queue():
    cap = 10
    def __init__(self):
        self._data = [None]*queue.cap
        self.size = 0
        self.front = 0

    def __len__(self):
        return self.size

    def is_empty(self):
        if len(self) == 0:
            return True
        return False
   
    def is_full(self):
        return self.size == queue.cap 

    def first(self):
        if self.is_empty():
            raise Exception("empty queue")
        return self._data[self.front]

    def enqueue(self,ele):
        if self.is_full():
            self._resize(2*len(self._data))
        rear = (self.front + self.size)%len(self._data)
        self._data[rear] = ele
        self.size+=1

    def dequeue(self):
        if self.is_empty():
            raise Exception("empty queue")
        L = self._data[self.front]
        self._data[self.front]=None
        self.front = (self.front +1 )%len(self._data)
        self.size -=1
        return L

    def __str__(self) :
        return str(self._data)
        
    def _resize(self,c):
        old=self._data
        self._data = [None]*c
        w = self.front
        for L in range(len(old)):
            self._data[L]=old[w]
            w = (w+1)%len(old)
        self.front =0

    

A = queue()
A.enqueue(0)
A.enqueue(1)
A.enqueue(2)
print(A)