# -*- coding: utf-8 -*-
"""
Created on Mon Jun 27 12:18:45 2022

@author: user
"""

class Node:
    def __init__(self,key):
        self.left = None
        self.right = None
        self.val = key
    def printInorder(self,root):
        if root:
            self.printInorder(root.left)
            print(root.val)
            self.printInorder(root.right)

    def printPostorder(self,root):
        if root:
            self.printPostorder(root.left)
            self.printPostorder(root.right)
            print(root.val)
    def printPreorder(self,root):
        if root:
            print(root.val)
            self.printPreorder(root.left)
            self.printPreorder(root.right)

# Driver code
root = Node(1)
root.left      = Node(2)
root.right     = Node(3)
root.left.left  = Node(4)
root.left.right  = Node(5)
root.printPreorder(root)
#printInorder(root)

#printPostorder(root)
