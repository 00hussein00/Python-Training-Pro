# -*- coding: utf-8 -*-
"""
Created on Sun Jun 26 13:27:45 2022

@author: user
"""

class LinkedList:
     class Node:
         
         def __init__ (self, data, next = None): 		
             self.data = data			
             self.next = next
             			
         def __str__(self):
             return str(self.data)
         
     def __init__ (self):
         self. head = None 
         self. size = 0 
         
     def __str__ (self) :
        return str(self.head)
    
     def is_empty(self) :
        return self.size == 0
    
     def __len__(self):
         return self.size
        
     def tail(self):
         w = self.head
         while not(w == None):
             self.tale = w
             w=w.next
              
     def add_first(self,element):
        if self.is_empty():
            self.head = LinkedList().Node(element)
            self.size +=1
            self.tail = self.head
        else :
            old =self.head
            self.head = LinkedList().Node(element,old)
            self.size +=1
        
     def add_last(self,element):
         if self.is_empty():
            self.head = LinkedList().Node(element)
            self.size+=1
            self.tail = self.head
         else :
            old = self.tail
            new = LinkedList().Node(element)
            old.next = new
            self.tail = new
            self.size +=1
                   
     def delete_first(self):
         if self.is_empty():
             raise Exception("empty linked list")
         elif self.size == 1:
             self.head = None
             self.head = None
             self.size = 0
         else :
            self.head = self.head.next
            self.size -=1
    
     def display(self):
        L = 0
        l= " "
        w = self.head
        while not(w == None):
             l+=str(w)+" "
             w=w.next
             L+=1
             if L == len(self):
                 break
        print(l)
     
     def delete_last(self):
        if self.is_empty():
            raise Exception("empty linked list")
        elif self.size == 1:
            self.head = None
            self.head = None
            self.size = 0
        else :
            old = self.tail
            L=self.head
            while not(L.next == old):
                L=L.next
            self.tail = L
            self.size-=1
     
     def search(self, value):   
         if self.is_empty():
             raise Exception("is empty")
         else:
            temp=self.head
            while not(temp is None):
                if temp.data==value:
                   return True
                temp=temp.next
            return False
     
     def sort(self):
         pass
         
     def insert(self, value)  : 
         new=LinkedList().Node(value)
         if self.is_empty():
             self.head=new
             self.tail=new
             self.size +=1
         else:
             temp=self.head
             while temp.data <new.data:
                 temp=temp.next
             prev=self.head
             while prev.next != temp:
                 prev=prev.next
             prev.next=new
             new.next=temp
             self.size +=1
             
     def delete(self, value):     
        if self.is_empty():
            raise Exception("empty")
        else:
            flag=self.search(value)
            if flag==False:
                raise Exception("not exist")
            if self.head.data == value:
                self.delete_first()
            elif self.tail ==value:
                self.delete_last()
            else:
                temp=self.head
                while temp.next.data != value:
                    temp=temp.next
                temp.next=temp.next.next
                self.size-=1


         

A = LinkedList()
A.add_first(2)
A.add_first(1)
A.add_first(0)
A.add_first(12)
A.add_last(22)
#A.insert(44)
A.display()
         
        