# -*- coding: utf-8 -*-
"""
Created on Mon Jun 27 11:52:03 2022

@author: user
"""

class queue_Doubly :
    def __init__(self):
        self.head = self.Node(None)
        self.tail = self.Node(None)
        self.head.next = self.tail
        self.tail.prev = self.head
        self.size = 0
        
    class Node:
         def __init__ (self, data, next = None,prev=None): 		
             self.data = data			
             self.next = next
             self.prev = prev
         			
         def __str__(self):
             return str(self.data)
    
    def __len__(self):
        return self.size
    
    def is_empty(self):
        return self.size == 0
    
    def empty(self):
        if self.is_empty():
            raise Exception("empty queue Doubly Linked List")
    
    def insert_between(self,element,n,b):
        new = self.Node(element,n,b)
        n.prev = new
        b.next = new
        self.size +=1
        
    def __str__ (self) :
        return str(self.head.next)
    
    def display(self):
        self.empty()
        l= ["head"]
        w = self.head
        while not(w == None):
             l.append(w.data)
             w=w.next  
        for i in l :
            if i==None:
                l.remove(i)
        l.append("tail")
        print( l )
        
    def first(self):
        self.empty()
        return self.head.next.data
    
    def last(self):
        self.empty()
        return self.tail.prev.data
    
    def add_first(self,e):
        if self.is_empty():
            self.insert_between(e,self.tail,self.head)
            
        else :
            self.insert_between(e, self.head.next, self.head)
            
    def add_last(self,e):
        if self.is_empty():
            self.add_first(e)
        else :
            self.insert_between(e, self.tail, self.tail.prev)
            
    def delete_first(self):
        self.empty()
        old = self.head.next
        self.head.next = self.head.next.next
        self.head.next.next.prev = self.head        
        self.size -=1
        return old
    
    def delete_last(self):
        self.empty()
        old = self.tail.prev
        self.tail.prev = self.tail.prev.prev
        self.tail.prev.next =self.tail     
        self.size -=1    
        return old        
    
    
A = queue_Doubly()
A.add_first(4)
A.add_first(5)
A.add_first(55)
A.add_last(0)
A.add_last(1)
A.add_last(2)
A.delete_first()
A.delete_first()
A.delete_last()
A.display()
























        