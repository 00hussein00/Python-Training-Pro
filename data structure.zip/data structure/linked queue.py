# -*- coding: utf-8 -*-
"""
Created on Sun Jun 26 15:35:41 2022

@author: user
"""

class LinkedListQueue:
     class Node:
         
         def __init__ (self, data, next = None): 		
             self.data = data			
             self.next = next
             			
         def __str__(self):
             return str(self.data)
         
     def __init__ (self):
         self. head = None 
         self. size = 0 
         
     def __str__ (self) :
        return str(self.head)
    
     def is_empty(self) :
        return self.size == 0
    
     def __len__(self):
         return self.size
        
     def tail(self):
         w = self.head
         while not(w == None):
             self.tale = w
             w=w.next
             
     def first(self):
         if self.is_empty():
            raise Exception ("empty") 
         return self.head 
     
     def enqueue(self,element):
        if self.is_empty():
           self.head = LinkedListQueue().Node(element)
           self.size+=1
           self.tail = self.head
        else :
           old = self.tail
           new = LinkedListQueue().Node(element)
           old.next = new
           self.tail = new
           self.size +=1
           
     def dequeue(self):
       if self.is_empty():
           raise Exception("empty ")
       elif self.size == 1:
           self.head = None
           self.head = None
           self.size = 0
       else :
           old = self.head
           self.head=self.head.next
           self.size-=1
           return old

     def display(self):
       if self.is_empty():
            raise Exception("empty ")
       l= " "
       w = self.head
       while not(w == None):
            l+=str(w)+" "
            w=w.next
       print(l)
       
       
A=LinkedListQueue()
A.enqueue(0)
A.enqueue(1)
A.enqueue(2)
A.enqueue(3)
A.enqueue(4)
A.dequeue()
A.display()
print(A)            
