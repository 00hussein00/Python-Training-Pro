import ctypes
import selectors 

class Array ():
    
    def __init__(self,c = 10) : 
        self.__A = (c*ctypes.py_object)()
        self.__cap = c 
        self.__n = 0

    def get_cap(self):
        return(self.__cap)
    
    def set_cap(self,new):
        self.__cap = new            

    def get_size(self):
        return self.__n

    def is_empty(self):
        if self.__n  == 0 :
            return True
        else :
            return False

    def is_full(self):
        if self.__n == self.__cap :
            return True
        return False

    def __len__ (self):
        return self.__n

    def append (self,X):
        if self.is_full():
            self._resize(2*self.__cap)
        self.__A[self.__n] = X
        self.__n+=1
        
    def __getitem__(self,X):            
        if  (0<= X < self.__n) :
            return self.__A[X]
        else :
            raise Exception("empty Array")

    def __str__(self) :
        list1 = []
        list2 = []

        for i in range(len(self)):
            list1.append(str(self.__A[i]))
            list2.append(i)

            
        return str(list1) 
        
    def __setitem__(self,X,new):
        if 0<=X<self.__n:
            self.__A[X] = new
        else:
            raise Exception("Index out of range")

    def insert(self,value,index):
        if self.is_full():
            self._resize(2*self.__cap)
            self.append(value)
        else:
            if 0<= index<self.__n:
                for I in range(self.__n-1,index-1,-1) :#shift right
                    self.__A[I+1]=self.__A[I]
                self.__A[index] = value
                self.__n+=1

            else:
                raise Exception("Index out of range")

    def count(self,elem):
        if self.is_empty():
            raise Exception("empty array")
        else:
            c = 0
            for i in range(len(self)):
                if self.__A[i] == elem:
                    c+=1
            return c

    def find(self,elem):
        if self.is_empty():
            raise Exception("empty array")
        else:
            f = -1 
            for i in range(len(self)):
                if self.__A[i] == elem:
                    return i
            return f

    def _resize(self,b):
        B = (b*ctypes.py_object)()
        for i in range (self.__n):
            B[i]=self.__A[i]
        self.__A=B
        self.__cap = b

    def pop(self):
        if self.is_empty():
            raise Exception ("can't delete from empty array")
        else:
            L = self.__A[self.__n-1]
            self.__A[self.__n-1]=None
            self.__n-=1
            return L

    def remove(self,e):
        if self.is_empty():
            raise Exception("empty array")
        elif self.find(e) > -1 :
            f = self.find(e)
            for i in range(f,len(self)-1):
                self.__A[i]=self.__A[i+1]
            self.__n-=1

        else:
            raise Exception("not found") 






A = Array(2)
A.append(0)
A.append(1)
A.insert(2,4)
A.insert(3,2)
A.insert(0,4)
fai = A.find(0)
cou = A.count(2)
#[0] = 22
A.remove(0)

print(A)