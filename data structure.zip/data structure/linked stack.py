# -*- coding: utf-8 -*-
"""
Created on Sun Jun 26 15:26:45 2022

@author: user
"""

class LinkedListStack:
     class Node:
         
         def __init__ (self, data, next = None): 		
             self.element = data			
             self.next = next
             			
         def __str__(self):
             return str(self.element)
         
     def __init__ (self):
         self. head = None 
         self. size = 0 
         
     def __str__ (self) :
        return str(self.head)
    
     def is_empty(self) :
        return self.size == 0
    
     def __len__(self):
         return(self.size)
     
     def push(self,e):
         o=self.head
         self.head=LinkedListStack().Node(e,o)
         self.size+=1
    
     def top(self):
         if self.is_empty():
             raise Exception("empty")
         return self.heat
    
     def display(self):
       if self.is_empty():
           raise Exception("empty")
       l= " "
       w = self.head
       while not(w == None):
            l+=str(w)+" "
            w=w.next
       print(l)
       
     def pop(self):
         if self.is_empty():
             raise Exception("empty")
         old=self.head 
         self.head = self.head.next
         self.size-=1         
         return old
       
       
       
       
A=LinkedListStack()
A.push(0)
A.push(1)
A.push(2)
A.pop()
A.display()