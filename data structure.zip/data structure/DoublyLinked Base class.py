# -*- coding: utf-8 -*-
"""
Created on Sun Jun 26 17:38:21 2022

@author: user
"""

class DoublyLinkedlist :
    def __init__(self):
        self.head = self.Node(None)
        self.tail = self.Node(None)
        self.head.next = self.tail
        self.tail.prev = self.head
        self.size = 0
        
    class Node:
         def __init__ (self, data, next = None,prev=None): 		
             self.data = data			
             self.next = next
             self.prev = prev
         			
         def __str__(self):
             return str(self.data)
    
    def __len__(self):
        return self.size
    
    def is_empty(self):
        return self.size == 0
    
    def empty(self):
        if self.is_empty():
            raise Exception("empty Doubly Linked List")
    
    def insert_between(self,element,n,b):
        new = self.Node(element,n,b)
        n.prev = new
        b.next = new
        self.size +=1
        
    def __str__ (self) :
        return str(self)
          
    def insert(self,element):
        if self.is_empty():
            self.insert_between(element, self.tail,self.head)
        
        elif self.size == 1:
            new = self.Node(element)
            if self.head.next.data < element:
                new = self.Node(element,self.tail,self.head.next)
                self.tail.prev = new
                self.head.next.next = new
                self.size +=1
            elif self.head.next.data > element :
                new = self.Node(element,self.tail.prev,self.head)
                self.head.next = new
                self.tail.prev.prev = new
                
                self.size +=1
            else :
                raise Exception("duplicate element")
                
        else:
            temph=self.head.next
            L = 0
            while (temph.data< element):
                L+=1
                temph=temph.next
                if L == len(self):
                    break
            self.insert_between(element,temph,temph.prev)
            
    def display(self):
        self.empty()
        l= ["head"]
        w = self.head
        while not(w == None):
             l.append(w.data)
             w=w.next  
        for i in l :
            if i==None:
                l.remove(i)
        l.append("tail")
        print( l )
        
    def delete(self,node):
        self.empty()
        predecessor = node.prev
        successor = node.next
        predecessor.next = successor
        successor.prev = predecessor
        self.size -=1
        data = node.data
        node.prev = node.next=node.data
        return data
        
        
A =DoublyLinkedlist()
A.insert(5)
A.insert(54)
A.insert(4)
A.insert(55)
A.insert(535)
A.delete(A.head.next)
A.display()
#print(A.tail.prev.prev)
        
     