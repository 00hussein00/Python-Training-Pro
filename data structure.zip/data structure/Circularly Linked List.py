# -*- coding: utf-8 -*-
"""
Created on Sun Jun 26 15:52:09 2022

@author: user
"""

class Circularly_Linked_List:
    def __init__(self,d=None):
        self.size=0
        self.tail = None
        
    class Node:
        def __init__ (self, data, next = None): 		
             self.data = data			
             self.next = next
             			
        def __str__(self):
             return str(self.data)
    
    def is_empty(self):
        return self.size == 0
    
    def __len__(self):
        return self.size
    
    def first(self):
        if self.is_empty():
            raise Exception("empty")
        return self.tail.next
    
    def add(self,e):
        new = self.Node(e)
        if self.is_empty():
            new.next=new
            #self.tail = new
            self.size+=1
        else:
            new.next = self.tail.next
            self.tail.next = new.next
            self.size +=1
            
    def delete(self):
        if self.is_empty( ):
            raise Exception(" Queue is empty" )
        oldhead = self. tail. next
        if self. size  == 1:                                
            self. tail = None                     
        else:
            self. tail. next = oldhead. next    
        self.size -= 1
        return oldhead. element

            
A = Circularly_Linked_List()
A.add(5)
A.add(4)
print(A.tail.next)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
         