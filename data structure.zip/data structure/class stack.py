

class stack :
    def __init__(self):
        self._data = []

    def __len__(self):
        return len(self._data)

    def is_empty(self):
        if len(self) == 0:
            return True
        return False
    
    def is_full(self):
        return False

    def push (self,ele):
        self._data.append(ele)

    def pop(self):
        if self.is_empty():
            raise Exception("empty stack")
        #L = self._data[-1]
        #self._data[-2] = self._data[-1]
        #
        L = self._data.pop()
        return L
    
    def top(self):
        if self.is_empty():
            raise Exception("empty stack")
        return self._data[-1]

    def __str__(self) :
        return str(self._data)




A=stack()
A.push(5)
A.push(4)
#A.pop()
print(A.pop())