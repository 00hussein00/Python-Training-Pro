class dequeue():
    cap = 2
    def __init__(self):
        self._data = [None]*dequeue.cap
        self.size = 0
        self.front = 0


    def __len__(self):
        return self.size

    def is_empty(self):
        if len(self) == 0:
            return True
        return False
   
    def is_full(self):
        return self.size == dequeue.cap 

    def first(self):
        if self.is_empty():
            raise Exception("empty queue")
        return self._data[self.front]

    def last(self):
        if self.is_empty():
            raise Exception("empty queue")
        rear = (self.front + self.size-1)%len(self._data)
        return self._data[rear]

    def add_last(self,ele):
        if self.is_full():
            self.resize(2*len(self._data))
        rear = (self.front + self.size)%len(self._data)
        self._data[rear] = ele
        self.size+=1

    def delete_first(self):
        if self.is_empty():
            raise Exception("empty queue")
        L = self._data[self.front]
        self._data[self.front]=None
        self.front = (self.front +1 )%len(self._data)
        self.size -=1
        return L

    def __str__(self) :
        return str(self._data)

    def delete_last(self):
        if self.is_empty():
            raise Exception("empty queue")
        b = (self.front + self.size -1 )%len(self._data)
        L = self._data[b]
        self._data[b]=None
        self.size -=1
        return L

    def add_first(self,ele):
        if self.is_full():
            self.resize(2*len(self._data))
        self.front = (self.front -1 )%len(self._data)
        self._data[self.front] = ele
        self.size +=1

    def resize(self,c):
        old=self._data
        self._data = [None]*c
        w = self.front
        for L in range(len(old)):
            self._data[L]=old[w]
            w = (w+1)%len(old)
        
        self.front =0
    

A = dequeue()
A.add_first(10)
A.add_first(20)
A.add_first(30)
A.add_last(0)
A.add_last(1)
A.add_last(2)

#f=A.first()
print(A.first())