import string

set1 = ("ALFA":A)
print(A)

A = "ALFA"
B ="BRAVO"
C = "CHARLIE" or "CHARLI"
D ="DELTA"
E = "ECHO" or "ECO"
F = "FOXTROT"
G = "GOLF"
H = "HOTEL"
I = "INDIA"
J = "JULIET"
K = "KILO"
L = "LIMA"
M = "MIKE" or "MAIK"
N = "NOVEMBER"
O = "OSCAR"
P = "PAPA"
Q= "QUEBEC"
R = "ROMEO"
S ="SIERRA"
T ="TANGO"
U = "UNIFORM"
V = "VICTOR"
W ="WHISKEY"
X ="X-RAY" or "Ecs-ray"
Y = "YANKEE"
Z = "ZULU"
#def enc (i) :
    
Sentence = str(input("enter sentence to encryption use IPA :"))

#try :
for i in Sentence :
    
   print(i)

#Exception : 
#    print(f"{Sentence} can't encryption")