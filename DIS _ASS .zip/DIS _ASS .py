from re import M


def mes_p(num):
    if (num > 7) :
        if num % 5 ==0 :
            print(f"{num} = 5 {((num//5)-1)*'+ 5 '}")

        elif num %3 == 0:
            print(F"{num} = 3 {((num//3)-1)*'+ 3 '}")

        else:
            M5 = num%5
            M3 = num%3
            M8 = num%8
            print(f"M8 : {M8} ,M5 : {M5} ,M3 : {M3}")
            if num%8 == 0:
                print(f"{num} = 3 + 5 {('+ 3 + 5 ')*((num//8)-1)}")
                
            elif M5 ==2 :
                print(f"{num} = 5 {'+ 5 '*((num//5)-3)}{'+ 3 '*((4))}")

            elif M5==4 and num % 2==0:
                num = num/2
                print(f"{int(num*2)} = ",f"5  {('+ 5 '*int(((num//5)-3)))}{('+ 3 '*((4)))}" ,'+',f"5  {('+ 5 '*int(((num//5)-3)))}{('+ 3 '*((4)))}")

            elif M8 == 1 :      
                print(f"{int(num)} = ",f"5  {('+ 5 '*int(((num//5)-4)))}{('+ 3 '*((6)))}" )

            elif M8 == 2 : #false
                print(f"{int(num)} = ",f"5  {('+ 5 '*int(((num//5)-2)))}{('+ 3 '*((3)))}")

    else :
        print(f"number less than ' 8 ' : { num } < 8 ")



#try :

#X = int(input("the number :"))
for i in range(10000):
    mes_p(i)

#except :
#    print("the number is not int") 