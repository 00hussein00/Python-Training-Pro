l=[]
print(dir(l))