print("ttttttt")
print("ff")